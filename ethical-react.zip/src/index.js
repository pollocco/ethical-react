import React from "react";
import { render } from "react-dom";
import {
  ApolloClient,
  InMemoryCache,
  ApolloProvider,
  useQuery,
  gql
} from "@apollo/client";
import GetRecipes from "./components/GetRecipes"
import RecipeForm from "./components/RecipeForm"
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from "react-bootstrap/Container";

const client = new ApolloClient({
  uri: 'http://localhost:4000/graphql',
  cache: new InMemoryCache()
});




function App() {
  return (
    <ApolloProvider client={client}>
      <Container>
      <div>
        <h2>Ethical Eating :^)</h2>
        <GetRecipes />
        <RecipeForm />
      </div>
      </Container>
    </ApolloProvider>
  );
}

render(<App />, document.getElementById('root'));

