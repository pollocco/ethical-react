import React from "react";
import {
  useQuery,
  gql
} from "@apollo/client";
import Card from "react-bootstrap/Card";
import ListGroup from "react-bootstrap/ListGroup";

const GET_RECIPES = gql`
  query GetRecipes {
    getRecipes {
        id
        name
        ingredients {
          ingredient {
            name
          }
          amount
          unit
        }
      }
    }
`;

function GetRecipes(){
  const {loading, error, data} = useQuery(GET_RECIPES);

  if(loading) return <p>Loading...</p>;
  if(error) return <p>Error!</p>;

  console.log(data.getRecipes)

  return data.getRecipes.map((recipe) => (
    <Card key={recipe.id} style={{width:'18rem', margin:'4rem'}}>
      <Card.Header>{recipe.name}</Card.Header>
        {recipe.ingredients.map((ingredient) => (
          <ListGroup variant="flush">
            <ListGroup.Item>{ingredient.ingredient.name}, {ingredient.amount} {ingredient.unit}</ListGroup.Item>
          </ListGroup>
        ))}
    </Card>
  ))
}

export default GetRecipes