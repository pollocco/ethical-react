import React from "react";
import {
  useQuery,
  gql,
  useMutation
} from "@apollo/client";
import Button from "react-bootstrap/Button";
import Form  from "react-bootstrap/Form";
import Card from "react-bootstrap/Card";
import ListGroup from "react-bootstrap/ListGroup";


const NEW_RECIPE = gql`
mutation NewRecipe($id:ID, $name:String, $ingredients:[RecipeIngredientInput]) {
  newRecipe(
    id: $id
    name: $name
    ingredients: $ingredients
  ) {
    name
    ingredients {
      ingredient {
        name
      }
      amount
      unit
    }
  }
}
`;

const GET_RECIPES = gql`
  query GetRecipes {
    getRecipes {
        id
        name
        ingredients {
          ingredient {
            name
          }
          amount
          unit
        }
      }
    }
`;


const GET_INGREDIENTS = gql`
query GetIngredients {
  getIngredients {
    name
  }
}
`;

const picked_ingredients = []

function IngredientCheckboxes(){
    const {loading, error, data} = useQuery(GET_INGREDIENTS);
  
    if(loading) return <p>Loading...</p>;
    if(error) return <p>Error!</p>;
  
    console.log(data.getRecipes)
  
    return data.getIngredients.map(({name}) => (
      <div>
      <Form.Label for={name}>
      <Form.Check 
        type={`checkbox`}                
        id={name}
        label={name}
        value={name}
        onClick={e=>{
            if(picked_ingredients.indexOf(e.target.value) == -1){
                picked_ingredients.push(e.target.value)
            }
            else if(picked_ingredients.indexOf(e.target.value) != -1){
                picked_ingredients.pop(picked_ingredients.indexOf(e.target.value))
            }
            console.log(picked_ingredients)
        }}
      />
      </Form.Label>
      </div>
    ))
  }

function RecipeForm(){
  const {loading, error, data, refetch} = useQuery(GET_RECIPES)
  const [newRecipe] = useMutation(NEW_RECIPE)

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error :(</p>;

  let id, name
  return (
    <div>
        <Form onSubmit={e=>{
            e.preventDefault();
            var get_in_there = picked_ingredients.map((ingredient)=>{
                return {
                    ingredient:{name:ingredient},
                    amount:2,
                    unit:"test"}
            })
            console.log(id.value, name.value, get_in_there)
            newRecipe({variables:{id:id.value, name:name.value, ingredients:get_in_there}}).then(()=>window.location.reload(false))
            id.value = ''
            id.name = ''
        }}>
        <label for={'id'}>Id</label>
        <input name={'id'} ref={node=>{id = node}}/>
        <label for={'name'}>Name</label>
        <input name={'name'} ref={node=>{name = node}}/>
        <IngredientCheckboxes/>
        <Button type={'submit'}>Submit</Button>
        </Form>
    </div>
  )
}
export default RecipeForm